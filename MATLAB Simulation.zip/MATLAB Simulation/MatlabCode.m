clear all
clc
[DOF2_RP ARMInfo] = importrobot("RP_Model.slx");
X_range = [-0.05 0.05];
y_range = [0.055 0.055];
Z_range = [0.1 0.20];
% Try This
wp = [[0.05 0.055 0.20]' [0.05 0.055 0.17]' [0 0.055 0.17]' [0 0.055 0.20]' [0.05 0.055 0.20]' ];
wp = [wp wp];
